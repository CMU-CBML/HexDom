# Hybrid IGE-FEA mesh generation and simulation

## File folder structures
[grid_hybrid_demo]: contains all the necessary input files to generate hybrid IGA-FEA mesh and simulation files for grid geometry.
	[grid_simulation]: contains input files to generate LS-Dyna simulation file.
		[grid_LSDyna_Results]: contains simulation results from LS-Dyna (visualize d3eigv)
[Ibeam_hybrid_demo]: contains all the necessary input files to generate hybrid IGA-FEA mesh and simulation files for Ibeam geometry.
	[Ibeam_simulation]: contains input files to generate LS-Dyna simulation file.
		[Ibeam_LSDyna_Results]: contains simulation results from LS-Dyna (visualize d3eigv)
And all necessary execution files

## How to run
1. Run .bat file in each demo folder to generate mesh files
2. Once finished .bat file, use Hex2Spline to generate Bspline mesh (BEXT) from generated hex vtk file (some sharp features need to be defined to get better representation).
3. Merge all prism_xxxx.k files together as grid_prisms.k using LS-Prepost (in grid_simulation folder)
4. Merge duplicate points (keep larger node index) between prism and hexmesh to get grid_merged.k using LS-Prepost (in grid_simulation folder)
5. Add simulation settings and import commands to import BEXT file in .k files (grid_IGA.k)
6. Run simulation using LS-Dyna